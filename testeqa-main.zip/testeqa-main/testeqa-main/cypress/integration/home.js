describe('validando o botão continue shopping',() => {
  beforeEach (() => {
 
 cy. visit('https://www.saucedemo.com/');
 });
 
 it('realizando o acesso ao site', () => {
 cy.get('[data-test="username"]').type('standard_user');
 cy.get('[data-test="password"]').type('secret_sauce');
 cy.get('[class="submit-button btn_action"]').click();
 
 });
 });